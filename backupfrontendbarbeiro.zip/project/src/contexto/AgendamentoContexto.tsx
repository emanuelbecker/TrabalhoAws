import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Agendamento, HorarioDisponivel } from '../tipos';
import { agendamentos as dadosAgendamentos, gerarHorariosDisponiveis } from '../dados/dadosMock';
import { formatarData } from '../utils/dataUtils';

interface ContextoAgendamentoProps {
  agendamentos: Agendamento[];
  agendamentosFiltrados: Agendamento[];
  dataSelecionada: string;
  termoBusca: string;
  horariosDisponiveis: HorarioDisponivel[];
  setDataSelecionada: (data: string) => void;
  setTermoBusca: (termo: string) => void;
  confirmarAgendamento: (id: string) => void;
  recusarAgendamento: (id: string) => void;
  setBarbeiroSelecionadoId: (id: string) => void;
  barbeiroSelecionadoId: string;
}

const AgendamentoContexto = createContext<ContextoAgendamentoProps | undefined>(undefined);

export const ProvedorAgendamento: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>(dadosAgendamentos);
  const [dataSelecionada, setDataSelecionada] = useState<string>(formatarData(new Date(), 'yyyy-MM-dd'));
  const [termoBusca, setTermoBusca] = useState<string>('');
  const [barbeiroSelecionadoId, setBarbeiroSelecionadoId] = useState<string>('');
  const [horariosDisponiveis, setHorariosDisponiveis] = useState<HorarioDisponivel[]>([]);

  const agendamentosFiltrados = agendamentos.filter(agendamento => {
    const correspondeData = agendamento.data === dataSelecionada;
    const correspondeBarbeiro = agendamento.barbeiroId === barbeiroSelecionadoId;
    const correspondeBusca = termoBusca === '' || 
                         agendamento.nomeCliente.toLowerCase().includes(termoBusca.toLowerCase()) ||
                         agendamento.servico.toLowerCase().includes(termoBusca.toLowerCase());
    
    return correspondeData && correspondeBarbeiro && correspondeBusca;
  });

  useEffect(() => {
    if (barbeiroSelecionadoId && dataSelecionada) {
      const horarios = gerarHorariosDisponiveis(barbeiroSelecionadoId, dataSelecionada);
      setHorariosDisponiveis(horarios);
    }
  }, [barbeiroSelecionadoId, dataSelecionada, agendamentos]);

  const confirmarAgendamento = (id: string) => {
    setAgendamentos(agendamentos.map(agendamento => 
      agendamento.id === id ? { ...agendamento, status: 'confirmado' } : agendamento
    ));
  };

  const recusarAgendamento = (id: string) => {
    setAgendamentos(agendamentos.map(agendamento => 
      agendamento.id === id ? { ...agendamento, status: 'recusado' } : agendamento
    ));
  };

  return (
    <AgendamentoContexto.Provider
      value={{
        agendamentos,
        agendamentosFiltrados,
        dataSelecionada,
        termoBusca,
        horariosDisponiveis,
        setDataSelecionada,
        setTermoBusca,
        confirmarAgendamento,
        recusarAgendamento,
        setBarbeiroSelecionadoId,
        barbeiroSelecionadoId
      }}
    >
      {children}
    </AgendamentoContexto.Provider>
  );
};

export const useAgendamentos = () => {
  const contexto = useContext(AgendamentoContexto);
  if (contexto === undefined) {
    throw new Error('useAgendamentos deve ser usado dentro de um ProvedorAgendamento');
  }
  return contexto;
};