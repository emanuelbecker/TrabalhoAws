import React from 'react';
import { Barbeiro } from '../tipos';
import { Scissors, Star, Calendar } from 'lucide-react';

interface CartaoBarbeiroProps {
  barbeiro: Barbeiro;
  aoClicar: (barbeiroId: string) => void;
}

const CartaoBarbeiro: React.FC<CartaoBarbeiroProps> = ({ barbeiro, aoClicar }) => {
  return (
    <div 
      className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg transform hover:-translate-y-1 cursor-pointer"
      onClick={() => aoClicar(barbeiro.id)}
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={barbeiro.urlImagem} 
          alt={`Barbeiro ${barbeiro.nome}`}
          className="w-full h-full object-cover transition-all duration-500 hover:scale-105"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
          <div className="flex items-center text-white mb-1">
            <Star className="w-4 h-4 text-yellow-400 mr-1" />
            <span className="text-sm font-medium">{barbeiro.avaliacao.toFixed(1)}</span>
          </div>
        </div>
      </div>
      
      <div className="p-5">
        <h3 className="text-xl font-bold text-gray-900 mb-1">{barbeiro.nome}</h3>
        
        <div className="flex items-center text-gray-600 mb-3">
          <Scissors className="w-4 h-4 mr-2" />
          <p className="text-sm">{barbeiro.especialidade}</p>
        </div>
        
        <div className="flex items-center text-blue-600">
          <Calendar className="w-4 h-4 mr-2" />
          <p className="text-sm font-medium">{barbeiro.totalAgendamentos} agendamentos hoje</p>
        </div>
      </div>
    </div>
  );
};

export default CartaoBarbeiro;