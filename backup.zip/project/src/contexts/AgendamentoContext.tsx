import React, { createContext, useState, useContext, ReactNode } from 'react';
import { addDays, format, setHours, setMinutes } from 'date-fns';
import { ptBR } from 'date-fns/locale';

// Tipos
export interface Horario {
  id: string;
  hora: string;
  disponivel: boolean;
}

export interface Servico {
  id: string;
  nome: string;
  descricao: string;
  preco: number;
  duracao: number; // em minutos
}

export interface Cliente {
  nome: string;
  telefone: string;
  email: string;
}

export interface Barbeiro {
  id: string;
  nome: string;
  foto: string;
}

export interface Agendamento {
  id: string;
  cliente: Cliente;
  data: Date;
  horario: string;
  servico: Servico;
  barbeiro: Barbeiro;
  confirmado: boolean;
}

interface AgendamentoContextType {
  horarios: Horario[];
  servicos: Servico[];
  barbeiros: Barbeiro[];
  agendamentos: Agendamento[];
  clienteAtual: Cliente;
  servicoSelecionado: Servico | null;
  barbeiroSelecionado: Barbeiro | null;
  dataSelecionada: Date;
  horarioSelecionado: Horario | null;
  agendamentoConfirmado: Agendamento | null;
  atualizarCliente: (cliente: Cliente) => void;
  selecionarServico: (id: string) => void;
  selecionarBarbeiro: (id: string) => void;
  selecionarData: (data: Date) => void;
  selecionarHorario: (id: string) => void;
  confirmarAgendamento: () => void;
  obterHorariosDisponiveis: (data: Date, barbeiroId: string) => Horario[];
  obterBarbeirosDisponiveis: (data: Date) => Barbeiro[];
}

const AgendamentoContext = createContext<AgendamentoContextType | undefined>(undefined);

// Lista de barbeiros
const barbeirosDisponiveis: Barbeiro[] = [
  {
    id: '1',
    nome: 'João Silva',
    foto: 'https://images.pexels.com/photos/1805600/pexels-photo-1805600.jpeg'
  },
  {
    id: '2',
    nome: 'Pedro Santos',
    foto: 'https://images.pexels.com/photos/2076930/pexels-photo-2076930.jpeg'
  },
  {
    id: '3',
    nome: 'Carlos Oliveira',
    foto: 'https://images.pexels.com/photos/1878687/pexels-photo-1878687.jpeg'
  }
];

// Serviços oferecidos pela barbearia
const servicosDisponiveis: Servico[] = [
  { id: '1', nome: 'Corte de Cabelo', descricao: 'Corte masculino tradicional', preco: 35, duracao: 30 },
  { id: '2', nome: 'Barba', descricao: 'Modelagem e acabamento', preco: 25, duracao: 20 },
  { id: '3', nome: 'Combo (Cabelo + Barba)', descricao: 'Corte completo com barba', preco: 55, duracao: 50 },
  { id: '4', nome: 'Corte Degradê', descricao: 'Corte moderno com máquina', preco: 45, duracao: 40 },
  { id: '5', nome: 'Acabamento', descricao: 'Apenas acabamento e ajustes', preco: 20, duracao: 15 },
];

// Gerar horários disponíveis para um dia
const gerarHorarios = (): Horario[] => {
  const horarios: Horario[] = [];
  // Horários de 9h às 19h, a cada 30 minutos
  for (let hora = 9; hora < 19; hora++) {
    for (let minuto = 0; minuto < 60; minuto += 30) {
      // Se for hora de almoço (12-13h), marcar como indisponível
      const disponivel = !(hora === 12 && minuto === 0) && !(hora === 12 && minuto === 30);
      const horaFormatada = `${hora.toString().padStart(2, '0')}:${minuto.toString().padStart(2, '0')}`;
      
      horarios.push({
        id: `${hora}-${minuto}`,
        hora: horaFormatada,
        disponivel
      });
    }
  }
  return horarios;
};

export const AgendamentoProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [clienteAtual, setClienteAtual] = useState<Cliente>({ nome: '', telefone: '', email: '' });
  const [servicoSelecionado, setServicoSelecionado] = useState<Servico | null>(null);
  const [barbeiroSelecionado, setBarbeiroSelecionado] = useState<Barbeiro | null>(null);
  const [dataSelecionada, setDataSelecionada] = useState<Date>(new Date());
  const [horarioSelecionado, setHorarioSelecionado] = useState<Horario | null>(null);
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>([]);
  const [agendamentoConfirmado, setAgendamentoConfirmado] = useState<Agendamento | null>(null);
  
  const horarios = gerarHorarios();
  
  // Obter barbeiros disponíveis para uma data específica
  const obterBarbeirosDisponiveis = (data: Date): Barbeiro[] => {
    // Simular disponibilidade dos barbeiros
    return barbeirosDisponiveis.filter(() => Math.random() > 0.3);
  };
  
  // Simular horários já agendados
  const obterHorariosDisponiveis = (data: Date, barbeiroId: string): Horario[] => {
    const hoje = new Date();
    const diasDiferenca = Math.floor((data.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
    
    return horarios.map(horario => {
      const [hora, minuto] = horario.hora.split(':').map(n => parseInt(n));
      
      // Simular disponibilidade baseada no barbeiro e serviço selecionado
      const disponibilidade = Math.random() > 0.4 && horario.disponivel;
      
      // Garantir que horários passados de hoje não estejam disponíveis
      if (diasDiferenca === 0 && (hora < hoje.getHours() || (hora === hoje.getHours() && minuto < hoje.getMinutes()))) {
        return { ...horario, disponivel: false };
      }
      
      return { ...horario, disponivel: disponibilidade };
    });
  };
  
  // Atualizar dados do cliente
  const atualizarCliente = (cliente: Cliente) => {
    setClienteAtual(cliente);
  };
  
  // Selecionar serviço pelo ID
  const selecionarServico = (id: string) => {
    const servico = servicosDisponiveis.find(s => s.id === id) || null;
    setServicoSelecionado(servico);
    setBarbeiroSelecionado(null);
    setHorarioSelecionado(null);
  };
  
  // Selecionar barbeiro pelo ID
  const selecionarBarbeiro = (id: string) => {
    const barbeiro = barbeirosDisponiveis.find(b => b.id === id) || null;
    setBarbeiroSelecionado(barbeiro);
    setHorarioSelecionado(null);
  };
  
  // Selecionar data
  const selecionarData = (data: Date) => {
    setDataSelecionada(data);
    setBarbeiroSelecionado(null);
    setHorarioSelecionado(null);
  };
  
  // Selecionar horário pelo ID
  const selecionarHorario = (id: string) => {
    if (!barbeiroSelecionado) return;
    
    const horariosDisponiveis = obterHorariosDisponiveis(dataSelecionada, barbeiroSelecionado.id);
    const horario = horariosDisponiveis.find(h => h.id === id && h.disponivel) || null;
    setHorarioSelecionado(horario);
  };
  
  // Confirmar agendamento
  const confirmarAgendamento = () => {
    if (!servicoSelecionado || !horarioSelecionado || !barbeiroSelecionado || !clienteAtual.nome) {
      return;
    }
    
    const [hora, minuto] = horarioSelecionado.hora.split(':').map(n => parseInt(n));
    const dataHora = setMinutes(setHours(dataSelecionada, hora), minuto);
    
    const novoAgendamento: Agendamento = {
      id: `${Date.now()}`,
      cliente: clienteAtual,
      data: dataHora,
      horario: horarioSelecionado.hora,
      servico: servicoSelecionado,
      barbeiro: barbeiroSelecionado,
      confirmado: true
    };
    
    setAgendamentos([...agendamentos, novoAgendamento]);
    setAgendamentoConfirmado(novoAgendamento);
  };
  
  return (
    <AgendamentoContext.Provider value={{
      horarios,
      servicos: servicosDisponiveis,
      barbeiros: barbeirosDisponiveis,
      agendamentos,
      clienteAtual,
      servicoSelecionado,
      barbeiroSelecionado,
      dataSelecionada,
      horarioSelecionado,
      agendamentoConfirmado,
      atualizarCliente,
      selecionarServico,
      selecionarBarbeiro,
      selecionarData,
      selecionarHorario,
      confirmarAgendamento,
      obterHorariosDisponiveis,
      obterBarbeirosDisponiveis
    }}>
      {children}
    </AgendamentoContext.Provider>
  );
};

export const useAgendamento = () => {
  const context = useContext(AgendamentoContext);
  if (context === undefined) {
    throw new Error('useAgendamento deve ser usado dentro de um AgendamentoProvider');
  }
  return context;
};