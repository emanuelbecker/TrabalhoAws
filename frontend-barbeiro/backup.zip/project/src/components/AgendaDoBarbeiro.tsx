import React, { useState, useEffect } from 'react';
import { Barbeiro, Horario as HorarioType } from '../tipos/tipos';
import { getHorariosParaData } from '../dados/horarios';
import Horario from './Horario';
import { CalendarDays, User } from 'lucide-react';

type AgendaDoBarbeiroProps = {
  barbeiro: Barbeiro;
};

const AgendaDoBarbeiro: React.FC<AgendaDoBarbeiroProps> = ({ barbeiro }) => {
  const [dataSelecionada, setDataSelecionada] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [horarios, setHorarios] = useState<HorarioType[]>(
    getHorariosParaData(barbeiro.id, dataSelecionada)
  );

  const handleAceitarPedido = (horarioId: number) => {
    setHorarios(horarios.map(horario => 
      horario.id === horarioId 
        ? { ...horario, aceito: true }
        : horario
    ));
  };

  const handleRecusarPedido = (horarioId: number) => {
    setHorarios(horarios.map(horario => 
      horario.id === horarioId 
        ? { ...horario, ocupado: false, cliente: undefined, servico: undefined }
        : horario
    ));
  };

  const [diasDaSemana, setDiasDaSemana] = useState<{ data: string; nome: string }[]>([]);

  useEffect(() => {
    const hoje = new Date();
    const dias = [];
    const nomesDias = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    
    for (let i = 0; i < 7; i++) {
      const data = new Date(hoje);
      data.setDate(hoje.getDate() + i);
      dias.push({
        data: data.toISOString().split('T')[0],
        nome: i === 0 ? 'Hoje' : i === 1 ? 'Amanhã' : nomesDias[data.getDay()]
      });
    }
    
    setDiasDaSemana(dias);
  }, []);
  
  const horariosDisponiveis = horarios.filter(h => !h.ocupado);
  const horariosOcupados = horarios.filter(h => h.ocupado);

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex flex-col md:flex-row md:items-center mb-6 gap-4">
        <div className="w-24 h-24 rounded-full overflow-hidden flex-shrink-0 border-4 border-amber-500">
          {barbeiro.imagemUrl ? (
            <img 
              src={barbeiro.imagemUrl} 
              alt={`Foto de ${barbeiro.nome}`} 
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-slate-200">
              <User size={32} className="text-slate-400" />
            </div>
          )}
        </div>
        <div className="flex-grow">
          <h2 className="text-2xl font-bold text-slate-800">{barbeiro.nome}</h2>
          <p className="text-slate-600">{barbeiro.especialidade}</p>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex items-center mb-2">
          <CalendarDays size={20} className="mr-2 text-slate-700" />
          <h3 className="text-lg font-semibold">Selecionar Data</h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-7 gap-2">
          {diasDaSemana.map((dia) => (
            <button
              key={dia.data}
              onClick={() => {
                setDataSelecionada(dia.data);
                setHorarios(getHorariosParaData(barbeiro.id, dia.data));
              }}
              className={`
                p-2 rounded-md text-center transition-colors duration-200
                ${dataSelecionada === dia.data
                  ? 'bg-amber-500 text-white'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'}
              `}
            >
              <div className="text-sm font-semibold">{dia.nome}</div>
              <div className="text-xs">
                {new Date(dia.data).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="mb-8">
        <h3 className="text-xl font-semibold text-slate-600 mb-3 flex items-center">
          <span className="w-3 h-3 bg-gray-500 rounded-full mr-2"></span>
          Horários Disponíveis
        </h3>
        {horariosDisponiveis.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {horariosDisponiveis.map((horario) => (
              <Horario key={horario.id} horario={horario} />
            ))}
          </div>
        ) : (
          <p className="text-slate-500 italic">Nenhum horário disponível para esta data.</p>
        )}
      </div>

      <div>
        <h3 className="text-xl font-semibold text-green-600 mb-3 flex items-center">
          <span className="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
          Horários Agendados
        </h3>
        {horariosOcupados.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {horariosOcupados.map((horario) => (
              <Horario 
                key={horario.id} 
                horario={horario}
                onAceitarPedido={handleAceitarPedido}
                onRecusarPedido={handleRecusarPedido}
              />
            ))}
          </div>
        ) : (
          <p className="text-slate-500 italic">Nenhum horário agendado para esta data.</p>
        )}
      </div>
    </div>
  );
};

export default AgendaDoBarbeiro;