import React from 'react';
import BarbeiroCard from './BarbeiroCard';
import { Barbeiro } from '../tipos/tipos';

type ListaDeBarbeirosProps = {
  barbeiros: Barbeiro[];
  onSelecionarBarbeiro: (barbeiro: Barbeiro) => void;
};

const ListaDeBarbeiros: React.FC<ListaDeBarbeirosProps> = ({ barbeiros, onSelecionarBarbeiro }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {barbeiros.map((barbeiro) => (
        <BarbeiroCard
          key={barbeiro.id}
          barbeiro={barbeiro}
          onClick={() => onSelecionarBarbeiro(barbeiro)}
        />
      ))}
    </div>
  );
};

export default ListaDeBarbeiros;