export interface Barbeiro {
  id: number;
  nome: string;
  especialidade: string;
  imagemUrl: string;
  clientes: number;
}

export interface Horario {
  id: number;
  barbeiroId: number;
  data: string;
  hora: string;
  ocupado: boolean;
  cliente?: string;
  servico?: string;
  aceito?: boolean;
}